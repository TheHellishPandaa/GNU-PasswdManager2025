from setuptools import setup

setup(
    name='gnu-passwd-manager',
    version='1.0',
    description='A password manager with encryption and GUI',  # Descripción breve
    long_description='This is a password manager that uses encryption to store passwords securely. It provides a graphical interface to manage your passwords.',  # Descripción larga
    long_description_content_type='text/plain',  # Define el tipo de contenido para la descripción larga
    scripts=['GNU-PasswdManager.py'],
    install_requires=[
        'cryptography',
        'tkinter'
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
    ],
)
